function handlePostMessage(message) {
    let videoId = message.videoId;
    let userId = message.userId;
    let userName = message.userName;
    let newHtml = `
    <div class="video">
        <div class="id">${videoId}</div>
        <div class="UserId" id="${userId}">${userName}</div>               
    </div>
`;
// 특정 요소 선택 (예: class="target" 뒤에 삽입)
    let targetElements = document.getElementsByClassName("video")
    let targetElement = targetElements[targetElements.length - 1]
// targetElement 바로 뒤에 삽입
    if (targetElement) {
        targetElement.insertAdjacentHTML("afterend", newHtml);
    } else {
        console.error("Target element not found!");
    }
}

window.addEventListener("message", (event) => {
    handlePostMessage(event.data)
});